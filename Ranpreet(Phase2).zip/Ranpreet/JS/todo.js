// getting elemenets from html
var textField=document.getElementById('name');var AddButton=document.getElementById('addButton');var list=document.getElementById('tasks');
// adding action listenerAddButton.onclick=addItem;
// function to create new elemenets and add a new task to listfunction addItem() {
	// check if there is some text in taskname	if( textField.value == "" )	{		alert("Please enter a task Name first");	}
	// else add the task	else	{	
	// a new divsion with class 'task'	var newTask = document.createElement('div');	newTask.setAttribute('class', 'task');	// checkBox  	var checkBox=document.createElement('input');	checkBox.type='checkbox';	// adding event listener on clicking checkbox	checkBox.onclick=updateTask;	
	// adding h4 element as name of the task	var name = document.createElement('h4');	name.textContent = textField.value;	
	// adding delete button with class 'deleteButton'	var deleteButton = document.createElement('button');	deleteButton.textContent = 'X';	deleteButton.setAttribute('class','deleteButton');	// adding event listener on delete button 	deleteButton.onclick=deleteTask;
	// adding element in newTask division	newTask.appendChild(checkBox);	newTask.appendChild(name);	newTask.appendChild(deleteButton);	
	// prepend newTask in list of tasks	list.prepend(newTask);	}}
// updating the task if it is completed or notfunction updateTask(e) {
	// check if checkbox it is checked	if(e.target.checked == true)	{
	// adding line-through name    e.target.nextSibling.style.textDecoration = 'line-through';	// changing backgroundColor    e.target.parentNode.style.backgroundColor = 'red';
	// playing sound when it is checked	playSound();
	// adding item to last of the list    list.appendChild(e.target.parentNode);	}	else{	
	// removing text-decoration 	e.target.nextSibling.style.textDecoration = 'none';	// resetting color to lightgreen    e.target.parentNode.style.backgroundColor = 'lightgreen';	// adding back to top    list.prepend(e.target.parentNode);			}	}	function deleteTask(e) {	// deleting the item using event click    e.target.parentNode.parentNode.removeChild(e.target.parentNode);}
// function to play sound
// Already Used Audio APIfunction playSound() {	var audioFile = 'audio/Ding Sound Effect.mp3'      var sound = new Audio(audioFile);    sound.play();}


// Added Battery API to show Battery of the device
navigator.getBattery().then(function(battery) {

    document.getElementById('battery').value = battery.level * 100;
    document.getElementById('batteryValue').textContent = battery.level * 100+ "%";
	// on change of battery level updated value
	battery.addEventListener('levelchange', function(){
    document.getElementById('battery').value = battery.level * 100;
    document.getElementById('batteryValue').textContent = battery.level * 100+ "%";
  });
});

// used google map api to show map
var gmap = new google.maps.Map( document.getElementById('GoogleMap'), {zoom: 10, center: {lat: 44.410403, lng: -79.667330}});